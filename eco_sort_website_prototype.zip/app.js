const DB_KEY = "ecosort_demo_v1";
const bins = {
  recyclable: {name:"Blue Bin — Recyclable Waste", color:"blue"},
  organic: {name:"Brown Bin — Organic Waste", color:"brown"},
  general: {name:"Gray Bin — General Waste", color:"gray"}
};
const rewards = [
  {id:"seedling",name:"Little Seedling",emoji:"🌱",description:"A fresh start for your eco journey.",cost:30},
  {id:"earth",name:"Planet Protector",emoji:"🌎",description:"Show your love for the planet.",cost:60},
  {id:"goldenleaf",name:"Golden Leaf",emoji:"🍃",description:"A badge for greener choices.",cost:100},
  {id:"recycler",name:"Recycle Hero",emoji:"♻️",description:"You are making sorting a habit.",cost:150},
  {id:"sunshine",name:"Eco Sunshine",emoji:"☀️",description:"Brighten the future, one item at a time.",cost:220},
  {id:"forest",name:"Forest Guardian",emoji:"🌳",description:"A champion of a greener world.",cost:300}
];
let currentUser = null, correctBin = null, photoReady = false, answered = false;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function loadDB(){try{return JSON.parse(localStorage.getItem(DB_KEY))||{users:[]}}catch{return {users:[]}}}
function saveDB(db){localStorage.setItem(DB_KEY,JSON.stringify(db))}
function user(){return currentUser ? loadDB().users.find(u=>u.email===currentUser.email) : null}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function showView(name){
  if(["dashboard","play","rewards","leaderboard"].includes(name)&&!currentUser){name="login";toast("Please log in to continue.");}
  $$(".view").forEach(v=>v.classList.remove("active"));
  $("#view-"+name)?.classList.add("active");
  const logged=!!currentUser;
  $("#main-nav").classList.toggle("hidden",!logged);
  $("#account-area").innerHTML=logged?`<span class="muted" style="align-self:center;font-size:12px">${escapeHtml(user()?.username||"")}</span><button class="btn btn-ghost" id="logout">Log out</button>`:`<button class="btn btn-ghost" data-view="login">Log in</button><button class="btn btn-primary" data-view="signup">Sign up</button>`;
  if(logged) refresh();
  window.scrollTo({top:0,behavior:"smooth"});
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
document.addEventListener("click",e=>{
  const view=e.target.closest("[data-view]")?.dataset.view;if(view)showView(view);
  if(e.target.id==="logout"){currentUser=null;showView("home");toast("You have logged out.");}
});
$("#signup-form").addEventListener("submit",e=>{
  e.preventDefault();const f=new FormData(e.target),username=String(f.get("username")).trim(),email=String(f.get("email")).trim().toLowerCase(),password=String(f.get("password"));
  const db=loadDB();if(db.users.some(u=>u.email===email)){toast("An account with this email already exists.");return}
  db.users.push({username,email,password,points:0,sorted:0,claimed:[],activity:[],created:Date.now()});saveDB(db);currentUser={email};e.target.reset();showView("dashboard");toast("Welcome to ECO SORT!");
});
$("#login-form").addEventListener("submit",e=>{
  e.preventDefault();const f=new FormData(e.target),email=String(f.get("email")).trim().toLowerCase(),password=String(f.get("password"));const u=loadDB().users.find(x=>x.email===email&&x.password===password);
  if(!u){toast("Email or password is incorrect.");return}currentUser={email};e.target.reset();showView("dashboard");toast("Welcome back!");
});
function refresh(){
  const u=user();if(!u)return;
  $("#welcome-name").textContent=u.username;$("#stat-points").textContent=u.points;$("#stat-sorted").textContent=u.sorted;$("#stat-rewards").textContent=u.claimed.length;
  $("#play-points").textContent=u.points;$("#reward-points").textContent=u.points;
  $("#site-url").textContent=location.protocol.startsWith("http")?location.href.split("#")[0]:"Publish this site to create its public link.";
  $("#activity-list").innerHTML=u.activity.length?u.activity.slice(0,6).map(a=>`<div class="activity-item"><span>${escapeHtml(a.label)}</span><b>${a.points>0?"+":""}${a.points} pts</b></div>`).join(""):'<p class="muted">Your sorting activity will appear here.</p>';
  renderRewards();renderLeaderboard();renderQR();
}
function renderQR(){
  const box=$("#qrcode");if(!box)return;box.innerHTML="";
  if(location.protocol.startsWith("http")&&window.QRCode){new QRCode(box,{text:location.href.split("#")[0],width:100,height:100,colorDark:"#14532d",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.H});}
  else box.innerHTML='<span style="font-size:10px;color:#718075">QR appears<br>after publishing</span>';
}
$("#copy-link").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(location.href.split("#")[0]);toast("Website link copied.");}catch{toast("Copy is not available in this preview.");}});
$("#photo-input").addEventListener("change",e=>{
  const file=e.target.files[0];if(!file)return;
  if(!file.type.startsWith("image/")){toast("Please choose an image file.");return}
  if(file.size>8*1024*1024){toast("Please choose an image smaller than 8 MB.");e.target.value="";return}
  const reader=new FileReader();reader.onload=ev=>{$("#photo-preview").src=ev.target.result;$("#photo-preview").classList.remove("hidden");$("#upload-placeholder").classList.add("hidden");$("#sample-selector").classList.remove("hidden");photoReady=true;answered=false;correctBin=null;$("#feedback").classList.add("hidden");$("#next-item").classList.add("hidden");$$(".bin-choice").forEach(b=>b.disabled=true);toast("Photo added. Select a sample category for demo mode.");};reader.readAsDataURL(file);
});
$("#sample-item").addEventListener("change",e=>{
  correctBin=e.target.value||null;$$(".bin-choice").forEach(b=>b.disabled=!correctBin||answered);
});
$$(".bin-choice").forEach(btn=>btn.addEventListener("click",()=>{
  if(!photoReady||!correctBin||answered)return;
  const chosen=btn.dataset.bin;
  if(chosen===correctBin){
    answered=true;const db=loadDB(),u=db.users.find(x=>x.email===currentUser.email);u.points+=10;u.sorted+=1;u.activity.unshift({label:"Correctly sorted: "+bins[correctBin].name,points:10,time:Date.now()});saveDB(db);
    $("#feedback").className="feedback good";$("#feedback").textContent="Correct! Great job. You earned 10 points. Keep making a difference!";$("#next-item").classList.remove("hidden");$$(".bin-choice").forEach(b=>b.disabled=true);refresh();
  }else{$("#feedback").className="feedback bad";$("#feedback").textContent="Not quite! Try again. Think about what this item is made of.";$("#feedback").classList.remove("hidden");}
}));
$("#next-item").addEventListener("click",resetGame);
function resetGame(){photoReady=false;answered=false;correctBin=null;$("#photo-input").value="";$("#photo-preview").src="";$("#photo-preview").classList.add("hidden");$("#upload-placeholder").classList.remove("hidden");$("#sample-selector").classList.add("hidden");$("#sample-item").value="";$("#feedback").classList.add("hidden");$("#next-item").classList.add("hidden");$$(".bin-choice").forEach(b=>b.disabled=true);}
function renderRewards(){
  const u=user();if(!u)return;
  $("#reward-grid").innerHTML=rewards.map(r=>{const owned=u.claimed.includes(r.id),can=u.points>=r.cost;return `<article class="reward-card"><div class="reward-emoji">${r.emoji}</div><h3>${r.name}</h3><p>${r.description}</p><div class="reward-cost">⭐ ${r.cost} points</div><button class="btn ${owned?"btn-outline":"btn-primary"}" data-reward="${r.id}" ${owned||!can?"disabled":""}>${owned?"Unlocked":can?"Unlock reward":"Not enough points"}</button></article>`}).join("");
  $$("[data-reward]").forEach(b=>b.addEventListener("click",()=>{const reward=rewards.find(r=>r.id===b.dataset.reward),db=loadDB(),u=db.users.find(x=>x.email===currentUser.email);if(!reward||u.points<reward.cost||u.claimed.includes(reward.id))return;u.points-=reward.cost;u.claimed.push(reward.id);u.activity.unshift({label:"Unlocked: "+reward.name,points:-reward.cost,time:Date.now()});saveDB(db);refresh();toast("Reward unlocked: "+reward.name);}));
}
function renderLeaderboard(){
  const users=loadDB().users.slice().sort((a,b)=>b.points-a.points).slice(0,10);
  $("#leader-list").innerHTML=users.length?users.map((u,i)=>`<div class="leader-row"><span>${["🥇","🥈","🥉"][i]||("#"+(i+1))}</span><span>${escapeHtml(u.username)} ${currentUser&&u.email===currentUser.email?"(You)":""}</span><span>${u.points} pts</span></div>`).join(""):'<p class="muted">No players yet. Be the first to join!</p>';
}
$$(".year").forEach(x=>x.textContent=new Date().getFullYear());
showView("home");
